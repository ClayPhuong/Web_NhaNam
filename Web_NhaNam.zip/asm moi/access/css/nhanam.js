// Show - Hide form Đăng Ký
const btnDKs = document.querySelectorAll('.js-dk');
const modal1 = document.querySelector('.modal1');
const modal1Close = document.querySelector('.js-close');

function showDK() {
    modal1.classList.add('open');
}

function hideDK() {
    modal1.classList.remove('open');
}

for (const btnDK of btnDKs) {
    btnDK.addEventListener('click', showDK);
}

modal1Close.addEventListener('click', hideDK);

// Show - Hide form Đăng nhập
const btnDNs = document.querySelectorAll('.js-dn');
const modal2 = document.querySelector('.modal2');
const modal2Close2 = document.querySelector('.js-close2');

function showDN() {
    modal2.classList.add('open');
}

function hideDN() {
    modal2.classList.remove('open');
}

for (const btnDN of btnDNs) {
    btnDN.addEventListener('click', showDN);
}

modal2Close2.addEventListener('click', hideDN);

// Tạo slideshow
var hinhanh = [];
var j=0;
function loadimg() {
    for (let i = 0; i < 3; i++) {
        hinhanh[i] = new Image();
        hinhanh[i].src = "/access/IMG/banner" + i + ".jpg";
    }
}

function imgprev() {
    if (j>0) j--;
    document.getElementById("banner-img").src = hinhanh[j].src;
}

function imgnext() {
    if (j < hinhanh.length) j++;
    document.getElementById("banner-img").src = hinhanh[j].src;
}

var index = 0
changeimg = function() {
    var imgs = ['/access/IMG/banner0.jpg','/access/IMG/banner1.jpg','/access/IMG/banner2.jpg'];
    document.getElementById("banner-img").src= imgs[index];
    index++;
    if (index==3) index=0;
}
setInterval(changeimg, 2000);

// Tạo giỏ hàng

// var btn = document.getElementsByID("btnbuy")
// console.log(btn);
// document.getElementById("cart").style.display = "none"; // giỏ hàng bị ẩn

//     // hàm showhide
// function showhide(button) {
//     var x = document.getElementById("cart");
//     x.style.display = x.style.display == "block" ? "none" : "block";
// }

// var giohang = [];

// function addtocart(x) {
//     var pa = x.parentNode;
//     var hinh = pa.children[1].children[0].src;
//     var ten = pa.children[2].innerText;
//     var gia = pa.children[3].children[0].innerText;
//     var sl = 1;
//     var flag = 0;

//     // Kiểm tra tên sản phẩm trong giỏ hàng
//     for (var i = 0; i < giohang.length; i++) {
//         if (ten == giohang[i][1]) {
//             giohang[i][3] += 1;
//             flag =1;
//         }
//     }

//     // Khi chưa có sp trong giỏ hàng
//     if( flag == 0) {
//         item = [hinh, ten, gia, sl];
//         giohang.push(item);
//     }

//     //Xuất ra trong console log
//     console.log(giohang);
//     // Xuất ra trong bảng giỏ hàng
//     document.getElementById("mycart").innerHTML = showcart();
// }

// // show giỏ hàng
// function showcart() {
//     var kq = '';
//     var tongtien = 0;
//     var tongsl = 0;
//     for (var i = 0; i< giohang.length; i ++) {
//         kq += `<tr>
//             <td>${i + 1}</td>
//             <td><img src="${giohang[i][0]}"/></td>
//             <td>${giohang[i][1]}</td>
//             <td>${giohang[i][2]}</td>
//             <td>${giohang[i][3]}</td>
//             <td>${giohang[i][2] * giohang[i][3]}</td>
//             </tr>`
//         // tính tổng tiền
//         tongtien += giohang[i][2] * giohang[i][3];
//         tongsl += giohang[i][3];
//     }

//     kq += `<tr>
//             <th colspan = 5>Tổng tiền</th>
//             <th>${tongtien}</th>
//             </tr>`;
//     document.getElementById("countcart").innerText=tongsl//giohang.length;
//     return kq;
// }

// Mặc định giỏ hàng bị ẩn
document.getElementById("cartt").style.display = "none";

function showhide(button) {
    var x = document.getElementById("cartt");
    x.style.display = x.style.display == "block" ? "none" : "block";
}

var giohang = [];

function addtocart(button) {
    var pa = button.parentElement.parentElement;
    var hinh = pa.children[1].children[0].src;
    var ten = pa.children[2].innerText;
    var gia = pa.children[3].children[0].innerText;
    var soluong = 1;
    var flag = 0;
    var item = {hinh: hinh, ten: ten, gia: gia, soluong: soluong};
    // giohang.push(item);

    // Lưu sản phẩm lên bộ nhớ tạm:
    // console.log(giohang);

    // Kiểm tra xem có tên sản phẩm trong giỏ hàng chưa
    for (var i = 0; i < giohang.length; i++) {
        if (ten == giohang[i]['ten']) {
            giohang[i]['soluong'] += 1;
            flag = 1;
        }
    }

    // Nếu chưa có sản phẩm trong giỏ hàng
    if (flag == 0) {
        giohang.push(item);
    }

    // Lưu sản phẩm lên bộ nhớ, chuyển giỏ hàng object thành chuối json
    sessionStorage.setItem("giohang", JSON.stringify(giohang));


    // Show số lượng trên giỏ hàng
    document.getElementById("countcart").innerText = giohang.length;

    // Show ra trong bảng giỏ hàng 
    document.getElementById("mycart").innerHTML = showcart();
}

// function showcart() {
//     var gh = JSON.parse(sessionStorage.getItem("giohang"));
//     // console.log (gh);
//     var kq = ''; 
//     if (gh != null) {
//         for (let i=0; i<gh.length; i++) {
//             let total = parseInt(gh[i]['gia']) * parseInt(gh[i]['soluong']);
//             kq += `<tr>
//             <td> <img src="`+ gh[i]['hinh'] +`"> </td>
//             <td>` + gh[i]['ten'] + `</td>
//             <td> <span>` + gh[i]['gia'] + `</span>đ </td>
//             <td>` + gh[i]['soluong'] + `</td>
//             <td> ` + total + ` </td>
//             <td> <i class="ti-trash"></i> </td>
//         </tr>`
//         }
//     } else {
//         kq += "Giỏ hàng rỗng!";
//     }
// }
function showcart() {
    var kq = "";
    var tongtien = 0;
    var tongsl = 0;
    for (var i = 0; i < giohang.length; i++) {
        kq += `<tr>
            <td><img src="${giohang[i]['hinh']}"/></td>
            <td>${giohang[i]['ten']}</td>
            <td>${giohang[i]['gia']}đ</td>
            <td>${giohang[i]['soluong']}</td>
            <td>${giohang[i]['gia'] * giohang[i]['soluong']}đ</td>
            <td> <i class="ti-trash" onclick="xoaSP(this)"></i> </td>
            </tr>`
        //tính tổng tiền
        tongtien += giohang[i]['gia'] * giohang[i]['soluong'];
        tongsl += giohang[i]['soluong'];
    }
    kq += `<tr>
        <td colspan = 5>Tổng tiền</td>
        <td>${tongtien}đ</td>
        </tr>`;
        document.getElementById("countcart").innerText=tongsl//giohang.length;
    return kq;
}


// function xoaSP(x) {
//     // Xóa tr
//     var tr = x.parentElement.parentElement;
//     var tensp = tr.children[1].innerText;
//     tr.remove();
    
//     //  Xóa sp trong mảng
//     for (let i = 0; i< giohang.length; i++) {
//         if (giohang[i]['ten'] == tensp) {
//             giohang.splice(i,1);
//             // sessionStorage.removeItem(giohang[i]);
//             showcart();
//         }
//     }
//     // Cập nhật giỏ hàng
    
// }

function xoaSP(x) {
    giohang.splice(x,1);
    document.getElementById("mycart").innerHTML=showcart();
    if(giohang.length==0) {
        document.getElementById("giohang").style.display='none';
    }
}

// function xoatatca() {
//     giohang = [];
//     document.getElementById("mycart").remove;
//     sessionStorage.clear();
//     showcart();
// }

// Validate form đăng nhập 
// Form đăng nhập

function validate() {
    const tendn = document.getElementById("tendn");
    const mk = document.getElementById("mk");

    let inValid = true;

    if (isEmpty(tendn.value)) {
        tendn.classList.add("invalid");
        inValid = false;
    } else {
        tendn.classList.remove("invalid");
    }

    return inValid;
}

function isEmpty(val) {
    if (!!!val || val.trim()=='') {
        return true;
    } else {
        return false;
    }
}